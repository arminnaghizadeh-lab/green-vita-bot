"""Green Vita admin panel."""
